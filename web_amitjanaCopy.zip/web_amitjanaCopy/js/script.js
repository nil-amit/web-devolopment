// Selecting elements from the DOM using querySelector
let usernameInput = document.querySelector(".username");
let passwordInput = document.querySelector(".password");
let confirmPasswordInput = document.querySelector(".confirm-password");
//let showPasswordButton = document.querySelector(".password-button");
let face = document.querySelector(".face");

// Function to toggle password visibility and hand position
function togglePasswordVisibility() {
  // Check if the password is currently shown
  if (passwordInput.type === "text") {
    // If password is shown, make hands half-open
    document.querySelectorAll(".hand").forEach((hand) => {
      hand.classList.remove("peek");
      hand.classList.add("hide");
    });
    // Change password input type to password
    passwordInput.type = "password";
    confirmPasswordInput.type = "password";
  } else {
    // If password is hidden, make hands fully up
    document.querySelectorAll(".hand").forEach((hand) => {
      hand.classList.remove("hide");
      hand.classList.add("peek");
    });
    // Change password input type to text
    passwordInput.type = "text";
    confirmPasswordInput.type = "text";
  }
}

// Event listener for when the password input is focused
passwordInput.addEventListener("focus", (event) => {
  // Hide hands and make the tongue breath animation
  document.querySelectorAll(".hand").forEach((hand) => {
    hand.classList.add("hide");
  });
  document.querySelector(".tongue").classList.remove("breath");
});

// Event listener for when the password input is blurred
passwordInput.addEventListener("blur", (event) => {
  // Show hands and reset the tongue breath animation
  document.querySelectorAll(".hand").forEach((hand) => {
    hand.classList.remove("hide");
    hand.classList.remove("peek");
  });
  document.querySelector(".tongue").classList.add("breath");
});

// Event listener for when the confirm password input is focused
confirmPasswordInput.addEventListener("focus", (event) => {
  // Hide hands
  document.querySelectorAll(".hand").forEach((hand) => {
    hand.classList.add("hide");
  });
});

// Event listener for when the confirm password input is blurred
confirmPasswordInput.addEventListener("blur", (event) => {
  // Show hands
  document.querySelectorAll(".hand").forEach((hand) => {
    hand.classList.remove("hide");
    hand.classList.remove("peek");
  });
});

// Event listener for when the username input is focused
usernameInput.addEventListener("focus", (event) => {
  // Calculate hand rotation based on the length of the username
  let length = Math.min(usernameInput.value.length - 16, 19);
  document.querySelectorAll(".hand").forEach((hand) => {
    hand.classList.remove("hide");
    hand.classList.remove("peek");
  });

  // Set the rotation of the head
  face.style.setProperty("--rotate-head", `${-length}deg`);
});

// Event listener for when the username input is blurred
usernameInput.addEventListener("blur", (event) => {
  // Reset the rotation of the head
  face.style.setProperty("--rotate-head", "0deg");
});

// Event listener for input in the username field with throttling
usernameInput.addEventListener(
  "input",
  _.throttle((event) => {
    // Calculate hand rotation based on the length of the username
    let length = Math.min(event.target.value.length - 16, 19);
    // Set the rotation of the head
    face.style.setProperty("--rotate-head", `${-length}deg`);
  }, 100)
);

// Event listener for the show password button
//showPasswordButton.addEventListener("click", togglePasswordVisibility);


function validatePassword() {
  let password = document.getElementById("password").value;
  let confirmPassword = document.getElementById("confirm-password").value;

  // Check if passwords match
  let message = document.getElementById("message");
  let submitBtn = document.getElementById("submitBtn");

  if (password === confirmPassword) {
    message.innerHTML = '<span style="color: green; font-weight: bold; font-size: 1em;">Passwords match!</span>';
      submitBtn.disabled = false;
  } else {
      message.innerHTML = '<span style="color: red; font-weight: bold; font-size: 1em;">Passwords do not match!</span>';
      submitBtn.disabled = true;
  }
}

