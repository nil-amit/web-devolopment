<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "users";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$Name = $_POST['name'];
$Email = $_POST['email'];
$Subject = $_POST['subject'];
$Message = $_POST['message']; // Corrected variable name

// SQL query to insert data into the 'chopulas' table
$sql = "INSERT INTO chopulas (name, email, subject, massage) VALUES ('$Name', '$Email', '$Subject', '$Message')";

if ($conn->query($sql) === TRUE) {
    echo '<script>alert("We got your percious massage!\nwe will get back soon!");
    window.location.href = "../ichop.html";
    </script>';
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the database connection
$conn->close();
?>
