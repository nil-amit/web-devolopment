<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "users";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get username and password from the login form
$username = $_POST['username'];
$password = md5($_POST['password']); // Assuming you are storing passwords as MD5 hashes in the database

// SQL query to check if the username and password match
$sql = "SELECT * FROM user WHERE username = '$username' AND password = '$password'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Username and password match, redirect to ichop.html
    header("Location: ../ichop.html");
    exit();
} else {
    // Username or password is incorrect
    echo '<div style="position: relative; height: 100vh; background: url(\'../img/mamata.svg\') left bottom/50% no-repeat; text-align: right; display: flex; flex-direction: column; align-items: flex-end; justify-content: center;">';
    echo '<p style="color: green; font-size: 70px; font-weight: bold; text-shadow: 2px 2px 5px orange; margin: 0;">ভুল ! চপ পেলে না !</p>';
    echo '<p style="color: orange; font-size: 55px; text-shadow: 2px 2px 5px grey; font-weight: bold; margin: 0;">আবার চেষ্টা করো !</p>';
    echo '<a href="../index.html" style="background-color: #4CAF50; color: white; padding: 10px 20px; font-size: 26px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; position: relative; transition: box-shadow 0.3s;">
    <!-- Unicode character for left arrow: &larr; -->
    &#9666; retry
    </a>';
    echo '<style>
    a:hover {
        box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.5);
    }
    </style>';
    echo '</div>';
}

// Close the database connection
$conn->close();
?>
