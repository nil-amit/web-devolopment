<?php 
$servername="localhost";
$username = "";
$password = "";
$dbname = "users"

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$userName=$_GET['username'];
$userPass=$_GET['password'];

$ePass=md5($userPass);


$sql = "INSERT INTO users (username, password)
VALUES ('$userName', '$ePass')";

if (mysqli_query($conn, $sql)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);


?>