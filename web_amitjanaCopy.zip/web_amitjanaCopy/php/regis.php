<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "users";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//echo "Connection done ";

// Get form data
$Name = $_POST['name'];
$Email = $_POST['email'];
$Username = $_POST['username'];
$Password = md5($_POST['password']); // Corrected variable name
$cPassword = md5($_POST['confirm-password']);

//if password and confirm-password same
//if ($Password == $cPassword) {
// SQL query to insert data into the 'chopulas' table
$sql = "INSERT INTO user (name, email, username, password) VALUES ('$Name', '$Email', '$Username', '$cPassword')";

if ($conn->query($sql) === TRUE) {

    echo '<div style="position: relative; height: 100vh; background: url(\'../img/mamata.svg\') left bottom/50% no-repeat; text-align: right; display: flex; flex-direction: column; align-items: flex-end; justify-content: center;">';
    echo '<p style="color: green; font-size: 50px; font-weight: bold; text-shadow: 2px 2px 5px orange; margin: 0;">সাব্বাস! খাতা খোলা হয়ে গেছে!</p>';
    echo '<p style="color: orange; font-size: 50px; text-shadow: 2px 2px 5px grey; font-weight: bold; margin: 0;">এবার ধার করতে পারবে !</p>';
    echo '<a href="../index.html" style="background-color: #4CAF50; color: white; padding: 10px 20px; font-size: 26px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; position: relative; transition: box-shadow 0.3s;">
    <!-- Unicode character for left arrow: &larr; -->
    &#9666; Back to login
</a>';
    echo '<style>
    a:hover {
        box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.5);
    }
</style>';
    echo '</div>';
       
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
//} else echo '<script>alert("Variables are not the same!");</script>';
    
?>
