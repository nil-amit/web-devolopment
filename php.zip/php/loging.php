<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "users";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully with database";
// Get username and password from the login form
$username = $_POST['username'];
$password = md5($_POST['password']); // Assuming you are storing passwords as MD5 hashes in the database

// SQL query to check if the username and password match
$sql = "SELECT * FROM user WHERE username = '$username' AND password = '$password'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Username and password match, redirect to ichop.html
    header("Location: ichop.html");
    exit();
} else {
    // Username or password is incorrect
    echo "Invalid username or password.";
}

// Close the database connection
$conn->close();
?>
