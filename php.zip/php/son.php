<?php
$servername = "localhost";
$username = "root";
$password = "";
$db="project";

// Create connection
$conn = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
//echo "Connected successfully with database";

$name=$_GET['name'];
$email=$_GET['email'];
$subject=$_GET['subject'];
$massege=$_GET['massege'];


$sql = "INSERT INTO chopulas (name, email, subject, massage) VALUES ('$name', '$email', '$subject', '$massage')";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  // output data of each row
  while($row = mysqli_fetch_assoc($result)) {
    echo "WELCOME " . $row["username"]."<br>";
  }
} else {
  echo "0 results";
}

mysqli_close($conn);



echo "<h1>Hello !!!</h1>";

include('con.php');
$userName=$_GET['username'];
$userPass=$_GET['password'];

$ePass=md5($userPass);


$sql = "INSERT INTO users (username, password)
VALUES ('$userName', '$ePass')";

if (mysqli_query($conn, $sql)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);

?>