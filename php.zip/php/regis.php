<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "users";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connection done ";

// Get form data
$Name = $_POST['name'];
$Email = $_POST['email'];
$Username = $_POST['username'];
$Password = md5($_POST['password']); // Corrected variable name
$cPassword = md5($_POST['confirm-password']);

//if password and confirm-password same
if ($Password == $cPassword) {
// SQL query to insert data into the 'chopulas' table
$sql = "INSERT INTO user (name, email, username, password) VALUES ('$Name', '$Email', '$Username', '$cPassword')";

if ($conn->query($sql) === TRUE) {
    echo "Form submitted successfully!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the database connection
$conn->close();
} else echo '<script>alert("Variables are not the same!");</script>';
?>
